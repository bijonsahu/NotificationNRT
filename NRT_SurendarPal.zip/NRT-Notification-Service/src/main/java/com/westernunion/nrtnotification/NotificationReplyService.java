package com.westernunion.nrtnotification;

import com.westernunion.schema.xrsi.NisNotificationReply;

import com.westernunion.schema.xrsi.NisNotificationRequest;
import com.westernunion.schema.xrsi.ObjectFactory;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Service;

@XmlRootElement
@Service
public class NotificationReplyService {

    public static NisNotificationReply checkeligibility (NisNotificationRequest request){
  	    ObjectFactory factory = new ObjectFactory();
	    NisNotificationReply nisNotificationReply = factory.createNisNotificationReply();
        nisNotificationReply.setPartner(request.getPartner());
        nisNotificationReply.setDevice(request.getDevice());
        nisNotificationReply.setSender(request.getSender());
        nisNotificationReply.setReceiver(request.getReceiver());
        nisNotificationReply.setPaymentDetails(request.getPaymentDetails());
        nisNotificationReply.setTransactionId(request.getTransactionId());
        nisNotificationReply.setMoneyTransferControl(request.getMoneyTransferControl());
        nisNotificationReply.setNotificationType(request.getNotificationType());
        nisNotificationReply.setAckMessage("SUCCESS");
        return nisNotificationReply;

    }
    }