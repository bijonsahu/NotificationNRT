package com.westernunion.nrtnotification;
import com.westernunion.nrtnotification.NotificationReplyService;
import com.westernunion.schema.xrsi.NisNotificationReply;
import com.westernunion.schema.xrsi.NisNotificationRequest;
import com.westernunion.schema.xrsi.ObjectFactory;

import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@XmlRootElement
@Endpoint
public class NisNotificationEndpoint {

    private static final String NAMESPACE="http://www.westernunion.com/schema/xrsi";
    
      @Autowired
      private NotificationReplyService service;
      @PayloadRoot(namespace = NAMESPACE, localPart = "nis-notification-request")
      @ResponsePayload
      public NisNotificationReply getNotification (@RequestPayload NisNotificationRequest nisNotificationRequest){
          return service.checkeligibility(nisNotificationRequest);
    }
  
   
   
}